package com.example.lab4ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class EmoijActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emoij);
    }
}
